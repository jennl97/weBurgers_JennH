//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

print("Do you wish to place an order?")

var yes = true
var no = false
var answer:Bool

let rand = arc4random_uniform(100)
if(rand<50) {answer = true} else { answer = false}

if answer==true{
    print("What burger would you like?")
    
}
else{
        print("Thank you for visiting WeBurgers")
    }

var order:String?

enum burgers:UInt32 {
    case bbqBaconCheddarBurger
    case smokeHouseBurger
    case phillyCheeseSteakBurger
    case cheesyBaconCowboyBurger
    case bigKahunaHawaiianBurger
    case spicyBuffaloChickenBurger
}

struct condiments {
    var lettuce:String?
    var tomato:String?
    var pickle:String?
    var mayo:String?
    var mustard:String?
    var ketchup:String?
    var cheese:String?
    
}

func whatBurger() {
        let rand2 = arc4random_uniform(6)
        switch burgers(rawValue: rand2)!
        {
        case .bbqBaconCheddarBurger:
            order="BBQ Bacon Cheddar Burger"
        case .smokeHouseBurger:
            order="Smokehouse Burger"
        case .phillyCheeseSteakBurger:
            order="Philly CheeseSteak Burger"
        case .cheesyBaconCowboyBurger:
            order="Cheesy Bacon Cowboy Burger"
        case .bigKahunaHawaiianBurger:
            order="Big Kahuna Hawaiian Burger"
        case .spicyBuffaloChickenBurger:
            order="Spicy Buffalo Chicken Burger"
            
        }
    return
        
    }

whatBurger()

var c = condiments()
print("What would you like on that?")

print("Lettuce?")
var r1 = arc4random_uniform(100)
if(r1<50) {c.lettuce = "Lettuce"}

print("Tomato?")
var r2 = arc4random_uniform(100)
if(r2<50) {c.tomato = "Tomato"}

print("Pickle?")
var r3 = arc4random_uniform(100)
if(r3<50) {c.pickle = "Pickle"}

print("Mayo?")
var r4 = arc4random_uniform(100)
if(r4<50) {c.mayo = "Mayo"}

print("Mustard?")
var r5 = arc4random_uniform(100)
if(r5<50) {c.mustard = "Mustard"}

print("Ketchup?")
var r6 = arc4random_uniform(100)
if(r6<50) {c.ketchup = "Ketchup"}

print("Cheese?")
var r7 = arc4random_uniform(100)
if(r7<50) {c.cheese = "Cheese"}

print(order!)
if (c.lettuce != nil){
    print("\t" + c.lettuce!)
    
}

if (c.tomato != nil){
    print("\t" + c.tomato!)

}

if (c.pickle != nil){
    print("\t" + c.pickle!)
    
}

if (c.mayo != nil){
    print("\t" + c.mayo!)
    
}

if (c.mustard != nil){
    print("\t" + c.mustard!)
    
}

if (c.ketchup != nil){
    print("\t" + c.ketchup!)
    
}

if (c.cheese != nil){
    print("\t" + c.cheese!)
    
}










